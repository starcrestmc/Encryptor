# Requires pre.py for passgen

################################## --- AES En/De cryptor --- ####################################

from MODULES import warnings
warnings.filterwarnings("ignore")

#import cffi
import os
from time import sleep as s

from pynput.keyboard import Controller, Key
from pynput.keyboard import Controller, Key, KeyCode
from pynput import mouse, keyboard
from pynput.mouse import Button

from random import randrange as rr
from random import choice as ch

from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from MODULES import base64
from MODULES import string
from MODULES.hashlib import sha256
from MODULES import pickle as pk
from MODULES import pre

import pyperclip as pyperclip

def derive_hkdf(salt: bytes, phrase: bytes, length: int = 32) -> bytes:
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=length,
        salt=salt,
        info=None,  # Optional context/application-specific info
        backend=default_backend()
    )
    return hkdf.derive(phrase)

# XOR FUNCTION #

def xor_bytes(a: bytes, b: bytes) -> bytes:
    max_len = max(len(a), len(b))
    a_padded = a.ljust(max_len, b'\x00') # Pad with spaces
    b_padded = b.ljust(max_len, b'\x00')
    return bytes(x ^ y for x, y in zip(a_padded, b_padded))

lower_alphabet = string.ascii_lowercase + string.digits + string.punctuation
upper_alphabet = string.ascii_uppercase + string.digits + string.punctuation

def shift_alphabet(alphabet, shift):
    shift = shift % len(alphabet)
    return alphabet[-shift:] + alphabet[:-shift]

def generate_key(msg, key):
    key_list = list(key)
    extended_key = key_list.copy()
    for i in range(len(msg) - len(key_list)):
        extended_key.append(key_list[i % len(key_list)])
    return extended_key

def encrypt_vigenere(msg, key, table_shift=0):
    shifted_lower = shift_alphabet(lower_alphabet, table_shift)
    shifted_upper = shift_alphabet(upper_alphabet, table_shift)
    key = generate_key(msg, key)
    encrypted = []

    for i, char in enumerate(msg):
        k_char = key[i % len(key)]
        if char in lower_alphabet:
            m_idx = lower_alphabet.index(char)
            k_idx = lower_alphabet.index(k_char.lower())  # Always use lowercase key
            new_idx = (m_idx + k_idx) % len(lower_alphabet)
            encrypted.append(shifted_lower[new_idx])
        elif char in upper_alphabet:
            m_idx = upper_alphabet.index(char)
            k_idx = lower_alphabet.index(k_char.lower())  # Same key
            new_idx = (m_idx + k_idx) % len(upper_alphabet)
            encrypted.append(shifted_upper[new_idx])
        else:
            encrypted.append(char)
    return ''.join(encrypted)

def decrypt_vigenere(msg, key, table_shift=0):
    shifted_lower = shift_alphabet(lower_alphabet, table_shift)
    shifted_upper = shift_alphabet(upper_alphabet, table_shift)
    key = generate_key(msg, key)
    decrypted = []

    for i, char in enumerate(msg):
        k_char = key[i % len(key)]
        if char in shifted_lower:
            c_idx = shifted_lower.index(char)
            k_idx = lower_alphabet.index(k_char.lower())
            new_idx = (c_idx - k_idx + len(lower_alphabet)) % len(lower_alphabet)
            decrypted.append(lower_alphabet[new_idx])
        elif char in shifted_upper:
            c_idx = shifted_upper.index(char)
            k_idx = lower_alphabet.index(k_char.lower())
            new_idx = (c_idx - k_idx + len(upper_alphabet)) % len(upper_alphabet)
            decrypted.append(upper_alphabet[new_idx])
        else:
            decrypted.append(char)
    return ''.join(decrypted)











def caesar(text, step, alphabets):
    def shift(alphabet):
        return alphabet[int(step):] + alphabet[:int(step)]

    shifted_alphabets = tuple(map(shift, alphabets))
    joined_aphabets = ''.join(alphabets)
    joined_shifted_alphabets = ''.join(shifted_alphabets)
    table = str.maketrans(joined_aphabets, joined_shifted_alphabets)
    return text.translate(table)

# 🔹 Generate a Secure 256-bit AES Key from a Password
def derive_key_from_password(password, salt=None):
    if salt is None:
        salt = os.urandom(32)  # 256-bit salt for extra entropy
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # 256-bit key
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key = kdf.derive(password.encode())
    return key, salt

# 🔹 Encrypt Function (No Padding, AES-GCM)
def encrypt_aes_gcm(plaintext, password):
    # Generate a random salt (32 bytes for extra entropy)
    salt = os.urandom(32)  # 256-bit salt

    # Derive a strong 256-bit key
    key, _ = derive_key_from_password(password, salt)

    # Generate a 12-byte IV (Nonce) as required by AES-GCM
    iv = os.urandom(12)  # 12-byte IV (standard for AES-GCM)

    # Create AES-GCM cipher
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())

    # Generate a random AAD (Associated Data)
    aad = os.urandom(32)  # 32 bytes of random associated data

    # Encrypt the plaintext with the authentication tag
    encryptor = cipher.encryptor()
    encryptor.authenticate_additional_data(aad)
    ciphertext = encryptor.update(plaintext.encode()) + encryptor.finalize()

    # Combine salt, IV, AAD, ciphertext, and tag
    encrypted_data = base64.b64encode(salt + iv + aad + ciphertext + encryptor.tag)

    return encrypted_data.decode()

# 🔹 Decrypt Function (AES-GCM without Padding)
def decrypt_aes_gcm(encrypted_data, password):
    # Decode from Base64
    encrypted_data = base64.b64decode(encrypted_data)

    # Extract Salt (32 bytes), IV (12 bytes), AAD (32 bytes), Ciphertext, and Tag
    salt = encrypted_data[:32]  # 32-byte salt
    iv = encrypted_data[32:44]  # 12-byte IV
    aad = encrypted_data[44:76]  # 32-byte AAD
    ciphertext = encrypted_data[76:-16]  # Ciphertext
    tag = encrypted_data[-16:]  # 16-byte Authentication Tag

    # Derive the key using the same salt
    key, _ = derive_key_from_password(password, salt)

    # Create cipher object
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
    decryptor = cipher.decryptor()
    decryptor.authenticate_additional_data(aad)

    # Decrypt and verify authentication tag
    decrypted_plaintext = decryptor.update(ciphertext) + decryptor.finalize()

    return decrypted_plaintext.decode()

def aes_encrypt():
    # Encrypt
    message = input('Enter your message: ')
    name = input("\nEnter your name: ")
    password = input('\nEnter First password: ')
    pass1 = encrypt_aes_gcm(message, password)
    #print("🔹 Pass 1:", pass1) Delete '#' for verbose logging

    hashd = sha256(pass1.encode('utf-8')).hexdigest()
    newmsg = pass1 + "-" + hashd

    message_bytes = newmsg.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    text = base64_message

    alphabets = (string.ascii_lowercase, string.ascii_uppercase, string.digits)
    stepval = input("\nShift Number?\n > ")  # Get Details for Ceasar
    toshift = caesar(str(text), step=int(stepval), alphabets=alphabets)  # Ceasar Shift String

    message = toshift
    password = input('\nEnter Second password: ')
    pass2 = encrypt_aes_gcm(message, password)
    #print("🔹 Pass 2:", pass2) Delete '#' for verbose logging

    message_bytes = name.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    encname = base64_message
    message = str(encname) + ":" + pass2
    password = input('\nEnter your Const. password: ')
    pass3 = encrypt_aes_gcm(message, password)
    print("\n🔹 Ciphertext: ", pass3)
    
    pyperclip.copy(str(pass3))
    print("\nCiphertext Copied to Clipboard!")
    
    input("\nPress Enter to Go Back...\n")
    start()





def aes_decrypt():
    # Decrypt
    encrypted_text = input('Enter your Ciphertext: ')
    password = input('Enter your Const. password: ')
    print(' ')
    try:
        pretext = decrypt_aes_gcm(encrypted_text, password)
    except:
        print('Invalid Const. password \n')
        encrypted_text = ''
        print('\nExiting...')
        s(2)
        exit()

    splitter1 = pretext.split(':')
    name = splitter1[0]
    base64_bytes = name.encode('ascii')
    message_bytes = base64.b64decode(base64_bytes)
    msgfrom = message_bytes.decode('ascii')
    encrypted_text = splitter1[1]

    password = input('Enter your Second password: ')
    try:
        decrypted_text = decrypt_aes_gcm(encrypted_text, password)
    except:
        print('Invalid password. \n')
        encrypted_text = ''
        print('\nExiting...')
        s(2)

    #print("🔹 Pass 2:", decrypted_text) Delete '#' for verbose logging
    text = decrypted_text


    alphabets = (string.ascii_lowercase, string.ascii_uppercase, string.digits)
    stepval = input("\nShift Count?\n")  # Get Details for Ceasar
    deshift = caesar(str(text), step=int(stepval), alphabets=alphabets)  # Ceasar Shift String


    try:
        base64_bytes = deshift.encode('ascii')
        message_bytes = base64.b64decode(base64_bytes)
        curmsg = message_bytes.decode('ascii')
    except:
        print('Invalid Shift. \n')
        deshift = ''
        print('Exiting...')
        s(2)

    splitter2 = curmsg.split('-')
    message = splitter2[0]
    hash = splitter2[1]

    check = sha256(message.encode('utf-8')).hexdigest()
    if check == hash:
        print('\nValid Hash!\n')
        encrypted_text = message
    else:
        print('Invalid Hash!')
        print('Info:\n(1) Message May have been tampered with \nOR\n(2) Message may be corrupt.')
        encrypted_text = ''
        print('\n Quitting...')
        s(3)
        exit()

    password = input('Enter your First password: ')
    try:
        decrypted_text = decrypt_aes_gcm(encrypted_text, password)
    except:
        print('Invalid password. \n')
        encrypted_text = ''
        print('Exiting...')
        s(2)
    print('\nFrom: ', msgfrom)
    print("\n🔹 Message: ", decrypted_text)
    input("\nPress Enter to Go Back...\n")
    start()

################################## --- Password Generator --- ####################################


def passgen():
    def check_and_fix_similarity(p1, p2):
        mid_brackets = ['(_)', '[_]', '{_}', '(-)', '[-]', '{-}', '(+)', '[+]', '{+}', '(=)', '[=]', '{=}', '(&)', '[&]', '{&}', '(%)', '[%]', '{%}']
        special_chars = ['@', '_', '!', '%', '^', '&', '>', '<', '?', '.', '#', '~', '-']
        side_brackets = {'(#': ')', '[#': ']', '{#': '}', '($': ')', '[$': ']', '{$': '}', '(=': ')', '[=': ']', '{=': '}'}

        def reroll_ptA(existing):
            from random import choice
            pool = [c for c in special_chars if c != existing]
            return choice(pool)

        def reroll_ptD(existing_type):
            from random import choice
            pool = [d for d in mid_brackets if (d[0] + d[-1]) != existing_type]
            return choice(pool)

        def reroll_ptG(existing_gL, existing_gR, existing_gLsymbol):
            from random import choice
            while True:
                gL = choice(list(side_brackets.keys()))
                gR = side_brackets[gL]
                gLsym = gL[1]
                # Reject if any of these match the original
                if (gL != existing_gL) or (gR != existing_gR) or (gLsym != existing_gLsymbol):
                    return gL, gR, gLsym

        # Check pt.A
        while p1["pt_A"] == p2["pt_A"]:
            p2["pt_A"] = reroll_ptA(p1["pt_A"])

        # Check pt.D bracket type
        while (p1["mid_bracket_type"] == p2["mid_bracket_type"]) or (p1["mid_symbol"] == p2["mid_symbol"]):
            p2["pt_D"] = reroll_ptD(p1["mid_bracket_type"])
            p2["mid_bracket_type"] = p2["pt_D"][0] + p2["pt_D"][-1]
            p2["mid_symbol"] = p2["pt_D"][1]

        # Check gR (closing bracket of side wrapper)
        while (p1["gL"] + p1["gR"] == p2["gL"] + p2["gR"]) or (p1["gL_symbol"] == p2["gL_symbol"]) or (p1["gR"] == p2["gR"]):
            gL, gR, gLsym = reroll_ptG(p1["gL"], p1["gR"], p1["gL_symbol"])
            p2["gL"] = gL
            p2["gR"] = gR
            p2["gL_symbol"] = gLsym

        return p1, p2


    class pt:
        @staticmethod
        def A():
            crs = ['@', '_', '!', '%', '^', '&', '>', '<', '?', '.', '#', '~', '-']
            x = rr(1, 13)
            return crs[x]

    # Word file caches
        def B(): # adverbs
            try:
                with open("nltk/STORE/av.pkl", "rb") as f:
                    av_ls = pk.load(f)
            except FileNotFoundError:
                av_ls = pre.av()
            av = ch(av_ls)
            return av

        def C(): # verbs
            try:
                with open("nltk/STORE/v.pkl", "rb") as f:
                    v_ls = pk.load(f)
            except FileNotFoundError:
                v_ls = pre.v()
            v = ch(v_ls)
            return v

        def D(): # midchar
            chs = ['(_)', '[_]', '{_}', '(-)', '[-]', '{-}', '(+)', '[+]', '{+}', '(=)', '[=]', '{=}', '(&)', '[&]', '{&}', '(%)', '[%]', '{%}']
            x = rr(0, 18) # Maximum Security
            return chs[x]

        def E(): #adjective
            try:
                with open("nltk/STORE/aj.pkl", "rb") as f:
                    aj_ls = pk.load(f)
            except FileNotFoundError:
                aj_ls = pre.aj()
            aj = ch(aj_ls)
            return aj

        def F(): #noun
            try:
                with open("nltk/STORE/n.pkl", "rb") as f:
                    n_ls = pk.load(f)
            except FileNotFoundError:
                n_ls = pre.n()
            n = ch(n_ls)
            return n

        def G(): #sidechar
            c1 = ['(#', '[#', '{#', '($', '[$', '{$', '(=', '[=', '{='] # Security LV.1 could be index 0-2 and Security LV 2 could be index 3-11
            mpr = {'(#': ')', '[#': ']', '{#': '}', '($': ')', '[$': ']', '{$': '}', '(=': ')', '[=': ']', '{=': '}'}
            a = rr(0, 8) # Maximum Security
            l = c1[a]
            r = mpr[l]
            return l, r

        def H():
            return rr(10000, 99999) #Maximum Security

    def joiner():
        while True:
            a = pt.A()
            b = pt.B()
            c = pt.C()
            d = pt.D()
            e = pt.E()
            f = pt.F()
            lr = pt.G()
            gL = lr[0]
            g = pt.H()
            gR = lr[1]

            # Extract symbols used
            all_symbols = [a, d[0], d[1], gL[0], gL[1], gR]
            flat_symbols = "".join(all_symbols)
            used_chars = [char for char in flat_symbols if char in "@_!%^&><?.#~-=()[]{}"]
            if len(set(used_chars)) == len(used_chars):
                break  # All parts are unique

        full = f'{a}{b.title()}{c.title()}{d}{e.title()}{f.title()}{gL}{g}{gR}'
        
        return {
            "password": full,
            "pt_A": a,
            "pt_D": d,
            "mid_bracket_type": d[0] + d[-1],
            "gL": gL,
            "gR": gR,
            "gL_symbol": gL[1],
            "mid_symbol": d[1]
        }

    pw1 = joiner()
    pw2 = joiner()
    pw1, pw2 = check_and_fix_similarity(pw1, pw2)
    print(f"Your Password Is: {pw1['password']}")
    print(f"Your Password Is: {pw2['password']}")
    
    input('\nPress enter to Go back...\n\n\n')
    start()

    ################################## --- Start of code --- ####################################
def start():

    print('- Welcome to Freds Encrypter! -\n')
    print('(1) Generate Passwords')
    print('(2) Encrypt Text')
    print('(3) Decrypt Text')
    a = input('\n > ')
    if a == '1':
        passgen()

    elif a == '2':
        aes_encrypt()

    elif a == '3':
        aes_decrypt()

print("Notes: \n(1)Your PGP Private Key should be saved same place as this script with the name pv.asc")
print("(2) Your PGP Public Key should be saved same place as this script with the name pb.asc\n\n\n")
print("(3) When recieving, please put your message in msg.txt and save it\n\n\n")
start()
