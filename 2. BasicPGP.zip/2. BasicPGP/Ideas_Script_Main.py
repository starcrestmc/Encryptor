from hashlib import sha256
from MODULES import pgpy
import string
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import base64

from MODULES import PGPmsg
from MODULES import clipboard
import json
import os

# Load my config.json File to load shifts and stuff

if os.path.exists('config.json'):
    with open('config.json', 'r') as f:
        config = json.load(f)
else:
    config = {}

shiftx = config.get('shiftx')
shifty = config.get('shifty')
phrase = config.get('phrase')


if shiftx == 0 or shifty == 0: # Check The shift values were set before starting
    print("Please Set Shift Values in config.json!")
else:
    try:
        shiftx + shifty
        print("All Vars Set Without Error.")
    except TypeError:
        print("Please Set both variables to numbers")

pw1 = "password1islong"
pw2 = "Blank"

print(f'Summary: Pass1: {pw1} | Pass2: {pw2} | X: {shiftx} | Y: {shifty}') # Print Out The Values to confirm they were properly set
print(f'\nPhrase: {phrase}\n\n\n')

"""-----BEGIN PGP MESSAGE-----

wcBMA0Z9y2TZBwZsAQgAzvrn+3Uf602vMBQNgePnWzQG3xx0IF9+NNh9FuzSjAea
uJjVxfuFUSwTtxBUQ4OcL9Xg4kIyWFblemW/4/LFwdE9gQSScrApwS9V0sJLQNgW
fMfhVpp7z1EPSkHBnF306MusU0XMz9c/MvNuEByM+DDK44ZS79j6Y8KDw/DjKjvX
OKUfNv/107VtouaB6GUPLlf1nQF5Fel24STzanAnp5Y3OGbnGVvKEjjmgkJNWi29
ASoMbx1iHolFXAquFB3+mldFH2wS/XPHVhBiznxBM1KfTTFQClH1SpydxPVAgh9V
d7dCMR771JUJCtXhJGi4AqGWg6ETkcVQ7079FWzG5tLA3gHIVvOXBJAQNvFLG3bp
W7Q3FJDudgJ01WJznza6XhF3QIxMNFQTMGj/j9nzzRtx8tuyQF2jacIZPHIsFboT
/GazS8ECLJKRWfn0ggv+uvwdHGYuepuTgW3Wv2oRZ6nT6piYemxCNLilfeuZQDPm
okOivnyVDx8fZjvjFFQFfAs2APXoiw+HKQxZ91X3S31jyCGQN0Vf6zqBmCC8qsoE
y+Vz3RpRZnOUDEaD1h6KjqTGQWAjFbEy8tUZyMbdkzcouuiD47bwyEcpGCCIKEW+
lzAs/ZNSAUucIQlTF/euugp2VTfNWpt+iIxd59C3Hd+pUnsQr+fHwm5ZSf3Ps0qy
LKkVaFFQXMAVe1569Zqn3TT1JYqoQ0z2+XG38Khwl5y0LdBFb64su31ts2y0m6fv
X5Awtj/tlhrBbz9aoHk6E+ydco03ZNqJQADWWdv8R5AbmDMF+6Q9DFLo/Q3tcSB0
H3j8wwlcdeSeOpDSaiyE5FrZSDXckRS1b0mNvbDIYCTWujNPdt248eAHUupwakR3
Skm0kv2LY1UBorjPmFakFg==
=4ijY
-----END PGP MESSAGE-----"""
# Test Text
def caesar(text, step, alphabets): # Define the ceasar Shift (predefinined in main script so will be removed later
    def shift(alphabet):
        return alphabet[int(step):] + alphabet[:int(step)]

    shifted_alphabets = tuple(map(shift, alphabets))
    joined_aphabets = ''.join(alphabets)
    joined_shifted_alphabets = ''.join(shifted_alphabets)
    table = str.maketrans(joined_aphabets, joined_shifted_alphabets)
    return text.translate(table)

# --------------------------------- HKDF Function Add Into Main, Not Already Present --------------------------------- #

def derive_hkdf(salt: bytes, phrase: bytes, length: int = 32) -> bytes:
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=length,
        salt=salt,
        info=None,  # Optional context/application-specific info
        backend=default_backend()
    )
    return hkdf.derive(phrase)

# XOR FUNCTION #

def xor_bytes(a: bytes, b: bytes) -> bytes:
    max_len = max(len(a), len(b))
    a_padded = a.ljust(max_len, b'\x00') # Pad with spaces
    b_padded = b.ljust(max_len, b'\x00')
    return bytes(x ^ y for x, y in zip(a_padded, b_padded))

# --------------------------------- Vingerie Functions, Add Into Main, Not Already Present --------------------------------- #

lower_alphabet = string.ascii_lowercase + string.digits + string.punctuation
upper_alphabet = string.ascii_uppercase + string.digits + string.punctuation

def shift_alphabet(alphabet, shift):
    shift = shift % len(alphabet)
    return alphabet[-shift:] + alphabet[:-shift]

def generate_key(msg, key):
    key_list = list(key)
    extended_key = key_list.copy()
    for i in range(len(msg) - len(key_list)):
        extended_key.append(key_list[i % len(key_list)])
    return extended_key

def encrypt_vigenere(msg, key, table_shift=0):
    shifted_lower = shift_alphabet(lower_alphabet, table_shift)
    shifted_upper = shift_alphabet(upper_alphabet, table_shift)
    key = generate_key(msg, key)
    encrypted = []

    for i, char in enumerate(msg):
        k_char = key[i % len(key)]
        if char in lower_alphabet:
            m_idx = lower_alphabet.index(char)
            k_idx = lower_alphabet.index(k_char.lower())  # Always use lowercase key
            new_idx = (m_idx + k_idx) % len(lower_alphabet)
            encrypted.append(shifted_lower[new_idx])
        elif char in upper_alphabet:
            m_idx = upper_alphabet.index(char)
            k_idx = lower_alphabet.index(k_char.lower())  # Same key
            new_idx = (m_idx + k_idx) % len(upper_alphabet)
            encrypted.append(shifted_upper[new_idx])
        else:
            encrypted.append(char)
    return ''.join(encrypted)

def decrypt_vigenere(msg, key, table_shift=0):
    shifted_lower = shift_alphabet(lower_alphabet, table_shift)
    shifted_upper = shift_alphabet(upper_alphabet, table_shift)
    key = generate_key(msg, key)
    decrypted = []

    for i, char in enumerate(msg):
        k_char = key[i % len(key)]
        if char in shifted_lower:
            c_idx = shifted_lower.index(char)
            k_idx = lower_alphabet.index(k_char.lower())
            new_idx = (c_idx - k_idx + len(lower_alphabet)) % len(lower_alphabet)
            decrypted.append(lower_alphabet[new_idx])
        elif char in shifted_upper:
            c_idx = shifted_upper.index(char)
            k_idx = lower_alphabet.index(k_char.lower())
            new_idx = (c_idx - k_idx + len(upper_alphabet)) % len(upper_alphabet)
            decrypted.append(upper_alphabet[new_idx])
        else:
            decrypted.append(char)
    return ''.join(decrypted)

  #######################################################################################
 #                                                                                       #
#                                   ENCRYPTION                                            #
 #                                                                                       #
  #######################################################################################
 
def pass_enc():
    global pw1, pw2, shiftx, shifty, phrase
    # --------------------------------- Salt Calculations --------------------------------- #
    barehash = sha256(phrase.encode('utf-8')).hexdigest() # part 1 of the salt
    reversi = phrase [::-1] # second part of salt
    reversi = reversi.replace(" ", "")

    # Load the key (public or private)
    with open("PGPKeys/public.asc", "r") as f:
        key_data = f.read()
    key, _ = pgpy.PGPKey.from_blob(key_data)
    fingerprint = key.fingerprint # store the fingerprint / third part of salt

    total = str(barehash)+str(reversi)+str(fingerprint)
    print(f'Full Total String: {total}')
    totalhash = sha256(total.encode('utf-8')).hexdigest()
    print(f'Final Hash: {totalhash}\n')

    alphabets = (string.ascii_lowercase, string.ascii_uppercase, string.digits)
    shift = shiftx+shifty
    toshift = caesar(str(totalhash), step=int(shift), alphabets=alphabets)  # Ceasar Shift totalhash

    # --------------------------------- HKDF Calculation --------------------------------- #
    salt = toshift.encode()

    if isinstance(phrase, str):
        phrase = phrase.encode()
    else:
        pass

    derived_key = derive_hkdf(salt, phrase) # HKDF encode the phrase
    simplify_key = derived_key.hex()
    print(f'HKDF Key: {simplify_key.upper()}\n')

    # base64 encode the HKDF hash so it can be shifted OK.
    message_bytes = simplify_key.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    b64enc_key = base64_message

    alphabets = (string.ascii_lowercase, string.ascii_uppercase, string.digits)
    pw1vingkey = caesar(str(b64enc_key), step=int(shiftx), alphabets=alphabets)  # Ceasar Shift for password1 vingerie key
    pw2vingkey = caesar(str(b64enc_key), step=int(shifty), alphabets=alphabets) # Ceasar Shift for password2 vingerie key

    key = pw1vingkey
    shift = shiftx*shifty # the vingerie table shifted by shift X multiplied by shift Y
    shift = int(shift)
    pw1enc = encrypt_vigenere(pw1, key, table_shift=shift)
    print("Password 1 Encrypted:", pw1enc)

    key = pw2vingkey
    shift = shiftx//shifty # the vingerie table for 2 shifted by shift X floor divided by shift Y
    shift = int(shift)
    pw2enc = encrypt_vigenere(pw2, key, table_shift=shift)
    print("Password 2 Encrypted:", pw2enc)
    s1 = pw1enc
    s2 = pw2enc

    # --------------------------------- Interlacing --------------------------------- #

    def interleave_strings(s1, s2, eot='\x17'):
        result = []
        max_len = len(s2)  # s2 is always longer or equal
        for i in range(max_len):
            # Add char from s1 or EOT if s1 is shorter
            if i < len(s1):
                result.append(s1[i])
            else:
                result.append(eot)
            # Add char from s2 (always present)
            result.append(s2[i])
        return ''.join(result)
    
    combined = interleave_strings(s1, s2)
    print("\nCombined:", combined.encode())  # See control chars


    # --------------------------------- PGP Encryption --------------------------------- #

    print("\nNote:\n- Your Personal Keys will be auto generated in /PGPKeys\n")
    PGPmsg.test() # check and auto generate PGP Keypair
    
    if os.path.exists('config.json'):
        with open('config.json', 'r') as f:
            config = json.load(f)
    else:
        config = {}

    priv_1 = config.get('path_priv')
    
    privloc = f'PGPKeys/{priv_1}' # Personal private key location

    pub = input("Receiver's public key name (without .asc)?\n")
    fullfile = f'{pub}.asc' #Recievers key
    friendloc = "PGPKeys/" + str(fullfile)
    msg = combined
            
    run = PGPmsg.enc(privloc,friendloc,msg)
    print(" ")
    print(str(run))
    clipboard.copy(run)
    print("PGP Text Copied to Clipboard!")


  #######################################################################################
 #                                                                                       #
#                                   DECRYPTION                                            #
 #                                                                                       #
  #######################################################################################

def pass_dec():
    global pw1, pw2, shiftx, shifty, phrase, pgptextuh
    
    if os.path.exists('config.json'):
        with open('config.json', 'r') as f:
            config = json.load(f)
    else:
        config = {}

    priv_1 = config.get('path_priv')
    
    privloc = f'PGPKeys/{priv_1}' # Personal private key location
    
    sendrkey = input("Name of sender's public key for verification (without .asc)? ")
    fullfile = f'{sendrkey}.asc' #senders key
    truepath = "PGPKeys/" + str(fullfile)
    input("Please copy your ciphertext to clipboard Then Press enter to continue...") # ADD CIPHERTEXT VAR FOR TESTING
    clip = clipboard.paste()
    #clip = pgptextuh
    run = PGPmsg.dec(privloc,truepath,clip)
    dec_msg = run[0]
    verified = run[1]
    print("Decrypted message:\n", dec_msg.message)
    print("Signature verified:", bool(verified))
    combined = dec_msg.message


    def deinterleave_strings(s, eot='\x17'):
        s1 = []
        s2 = []
        # Since combined string is pairs, iterate in steps of 2
        for i in range(0, len(s), 2):
            c1 = s[i]
            c2 = s[i+1]
            # For s1, exclude placeholders
            if c1 != eot:
                s1.append(c1)
            s2.append(c2)
        return ''.join(s1), ''.join(s2)

    restored_s1, restored_s2 = deinterleave_strings(combined)
    print("Restored s1:", restored_s1)
    print("Restored s2:", restored_s2)
    pw1 = restored_s1
    pw2 = restored_s2
    # --------------------------------- Salt Calculations --------------------------------- #
    barehash = sha256(phrase.encode('utf-8')).hexdigest() # part 1 of the salt
    reversi = phrase [::-1] # second part of salt
    reversi = reversi.replace(" ", "")

    # Load the key (public or private)
    # Use receiver's public key instead so both sides derive the same fingerprint
    with open(truepath, "r") as f:
        key_data = f.read()
    key, _ = pgpy.PGPKey.from_blob(key_data)
    fingerprint = key.fingerprint

    total = str(barehash)+str(reversi)+str(fingerprint)
    print(f'Full Total String: {total}')
    totalhash = sha256(total.encode('utf-8')).hexdigest()
    print(f'Final Hash: {totalhash}\n')

    alphabets = (string.ascii_lowercase, string.ascii_uppercase, string.digits)
    shift = shiftx+shifty
    toshift = caesar(str(totalhash), step=int(shift), alphabets=alphabets)  # Ceasar Shift totalhash

    # --------------------------------- HKDF Calculation --------------------------------- #
    salt = toshift.encode()

    if isinstance(phrase, str):
        phrase = phrase.encode()
    else:
        pass

    derived_key = derive_hkdf(salt, phrase) # HKDF encode the phrase
    simplify_key = derived_key.hex()
    print(f'HKDF Key: {simplify_key.upper()}\n')

    # base64 encode the HKDF hash so it can be shifted OK.
    message_bytes = simplify_key.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    b64enc_key = base64_message

    alphabets = (string.ascii_lowercase, string.ascii_uppercase, string.digits)
    pw1vingkey = caesar(str(b64enc_key), step=int(shiftx), alphabets=alphabets)  # Ceasar Shift for password1 vingerie key
    pw2vingkey = caesar(str(b64enc_key), step=int(shifty), alphabets=alphabets) # Ceasar Shift for password2 vingerie key

    key = pw1vingkey
    shift = shiftx*shifty # the vingerie table shifted by shift X multiplied by shift Y
    shift = int(shift)
    
    pw1dec = decrypt_vigenere(pw1, key, table_shift=shift)
    print("Password 1 Decrypted:", pw1dec)

    key = pw2vingkey
    shift = shiftx//shifty # the vingerie table for 2 shifted by shift X floor divided by shift Y
    shift = int(shift)
    pw2dec = decrypt_vigenere(pw2, key, table_shift=shift)
    print("Password 2 Decrypted:", pw2dec)
    
PGPmsg.test()
a = input("(E)ncrypt or (D)ecrypt?\n")
if a.lower() == "e":
    pass_enc()
elif a.lower() == "d":
    pass_dec()
