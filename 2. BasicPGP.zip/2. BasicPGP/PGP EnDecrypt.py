from MODULES import PGPmsg
from MODULES import clipboard
import time
print("\nNote:\n- Your Personal Keys will be auto generated in /PGPKeys\n")
PGPmsg.test()

def menu():
    a = input("\n(E)ncrypt or (D)ecrypt?\n")
    privloc = "PGPKeys/private.asc" # Personal private key location
    
    if a.lower() == "e":
        pub = input("Receiver's public key name (without .asc)?")
        fullfile = f'{pub}.asc' #Recievers key
        friendloc = "PGPKeys/" + str(fullfile)
        msg = input("Message to encrypt?\n")
        
        run = PGPmsg.enc(privloc,friendloc,msg)
        print(str(run))
        clipboard.copy(run)
        print("\nCiphertext Copied to Clipboard!")
        
    elif a.lower() == "d":
        sendrkey = input("Name of sender's public key for verification (without .asc)? ")
        fullfile = f'{sendrkey}.asc' #senders key
        truepath = "PGPKeys/" + str(fullfile)
        input("Please copy your ciphertext to clipboard Then Press enter to continue...")
        clip = clipboard.paste()
        run = PGPmsg.dec(privloc,truepath,clip)
        dec_msg = run[0]
        verified = run[1]
        print("Decrypted message:\n", dec_msg.message)
        print("Signature verified:", bool(verified))
        time.sleep(3)
    else:
        exit()

menu()
