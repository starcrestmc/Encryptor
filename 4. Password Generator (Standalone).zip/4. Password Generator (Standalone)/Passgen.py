from random import randrange as rr
from random import choice as ch
import time as t
import pickle as pk
import pre
    #try: # Check if nltk is installed, if not ask user if they want to
import nltk
from nltk.corpus import brown
from nltk import pos_tag
nltk.download('brown')
nltk.download('averaged_perceptron_tagger_eng')
import time as t
    #except:
        #print("It seems like you don't have nltk installed")
        #print("Info: nltk is a dictionary used in this program so that the words to be used aren\'t limited \n")
        #toinstall = input("Would you like to install it? (y/n) \n> ")
        #if toinstall.lower() == "y": # Install nltk and also download word lists for later use
            #import os
            #os.system('cmd /k "@echo off & color a & echo [Python]: Installing NLTK Library & pip install nltk')
            #nltk.download('brown')
            #nltk.download('averaged_perceptron_tagger_eng')
        #else:
            #print("The password generator will not work without installing nltk \n")
            #print("Quitting...")
            #s(3)
            #exit()

class pt:
        @staticmethod
        def A():
            crs = ['@', '_', '!', '%', '^', '&', '>', '<', '?', '.', '#', '~', '-']
            x = rr(1, 13)
            return crs[x]

    # Word file caches
        def B(): # adverbs
            try:
                with open("av.pkl", "rb") as f:
                    av_ls = pk.load(f)
            except FileNotFoundError:
                av_ls = pre.av()
            av = ch(av_ls)
            return av

        def C(): # verbs
            try:
                with open("v.pkl", "rb") as f:
                    v_ls = pk.load(f)
            except FileNotFoundError:
                v_ls = pre.v()
            v = ch(v_ls)
            return v

        def D(): # midchar
            chs = ['(_)', '[_]', '{_}', '(-)', '[-]', '{-}', '(+)', '[+]', '{+}', '(=)', '[=]', '{=}', '(&)', '[&]', '{&}', '(%)', '[%]', '{%}']
            x = rr(0, 18) # Maximum Security
            return chs[x]

        def E(): #adjective
            try:
                with open("aj.pkl", "rb") as f:
                    aj_ls = pk.load(f)
            except FileNotFoundError:
                aj_ls = pre.aj()
            aj = ch(aj_ls)
            return aj

        def F(): #noun
            try:
                with open("n.pkl", "rb") as f:
                    n_ls = pk.load(f)
            except FileNotFoundError:
                n_ls = pre.n()
            n = ch(n_ls)
            return n

        def G(): #sidechar
            c1 = ['(#', '[#', '{#', '($', '[$', '{$', '(=', '[=', '{='] # Security LV.1 could be index 0-2 and Security LV 2 could be index 3-11
            mpr = {'(#': ')', '[#': ']', '{#': '}', '($': ')', '[$': ']', '{$': '}', '(=': ')', '[=': ']', '{=': '}'}
            a = rr(0, 8) # Maximum Security
            l = c1[a]
            r = mpr[l]
            return l, r

        def H():
            return rr(10000, 99999) #Maximum Security

def joiner():
        a = pt.A()
        b = pt.B()
        c = pt.C()
        d = pt.D()
        e = pt.E()
        f = pt.F()
        lr = pt.G()
        gL = lr[0]
        g = pt.H()
        gR = lr[1]
        print(f'{a}{b.title()}{c.title()}{d}{e.title()}{f.title()}{str(gL)}{g}{str(gR)}')

J = input("How Many Passwords to Make?\n")
for i in range(int(J)):
    joiner()
input("\n--- Press Enter to Exit ---\n\n\n")
print("⌜⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⎺⌝") 
print("⎸        Exiting...    |")
print("⌞_____________________⌟")
t.sleep(5)
exit()
    
